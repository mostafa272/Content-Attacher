=== Content Attacher ===
Contributors: Mostafa Shahiri
Tags: content, post, page, categories, attacher
Requires at least: 3.6.1
Tested up to: 4.8.x
Stable tag: 3.4.0

The Content Attacher appends custom contents to Wordpress posts or pages.

== Description ==

The Content Attacher appends custom contents to Wordpress posts or pages. You can manage items of the plugins in plugin options page in admin panel.
This plugin includes different filters to provide different types of customization for you. You can filter the items to display for different posts, pages, categories
, authors, ... before or after the content of pages or posts.

**Features:**

1) Items management.(You can add, update and delete items easily)

2) Easy to use

3) Appending custom content before or after posts content.

4) Different filters for showing each item. You can filter items to display based on posts, pages, categories, authors, post or page view.


== Installation ==

Upload Content Attacher plugin to your blog and Activate it.

== Screenshots ==

1. Plugin page in admin panel
2. Output

== Changelog ==

= 1.0 =
First release
